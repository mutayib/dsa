#include<stdio.h>
int main(){
    char ch;
        int a;
     float b;
     int x=4%5;    /* iss ka matlab hai ki ager ham 4 ko divide kray 5 sai too rem ye */
      printf("bytes occupied by ch=%d\n bytes occupied by a=%d\n bytes occupied by b=%d\n",sizeof(ch),sizeof(a),sizeof(b));
     printf("%d\n",x);
}