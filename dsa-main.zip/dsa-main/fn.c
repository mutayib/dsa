   #include<stdio.h>
    // fn decleation or prototype 
   void printhello(); //pahlay compiler ko kehrahay h ham aik fn bana rahay 
 int main(){
    printhello(); /*iss fn ko call lagaya in main fn ab iss fn ko jitne baar likhay ghay
    autna printhogha */
   return 0
 }
   // fn defination
 void printhello(){
    printf("hello!");
 } 

  