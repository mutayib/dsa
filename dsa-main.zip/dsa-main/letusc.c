#include<stdio.h>
int main(){
    int a; float b; char c;
    a=35; b=3.24; 
      printf("%d\t,%f\t,%d",a,b+1.5,235);


}