#include<stdio.h>
#include<string.h>
void main(){
  char s1[30];
    printf("enter the string s1");
      gets(s1);
    strlwr(s1);
     printf("%s",s1);
}